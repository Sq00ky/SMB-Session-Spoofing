#include <windows.h>
#include <tchar.h>
#include <strsafe.h>

#pragma comment(lib, "advapi32.lib")

using namespace std;
int main() {
    while (true) {
        STARTUPINFO si;
        PROCESS_INFORMATION pi;
        ZeroMemory(&si, sizeof(si));
        si.wShowWindow = 0;
        si.dwFlags = 0x00000001;
        wchar_t cmdLine[] = L"'C:\\Windows\\System32\\net.exe' use \\\\COMPUTER-IP-ADDRESS\\c$";
        CreateProcessWithLogonW(L"USER-TO-SPOOF", L"DOMAIN-TO-SPOOF", L"PASSWORD TO SPOOF", LOGON_NETCREDENTIALS_ONLY, L"C:\\Windows\\System32\\net.exe", cmdLine, NULL, NULL, NULL, &si, &pi);
        Sleep(750000);
    }
}